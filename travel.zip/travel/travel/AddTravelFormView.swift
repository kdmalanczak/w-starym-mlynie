//
//  AddTravelFormView.swift
//  travel
//
//  Created by Emil Małańczak on 09/11/2022.
//

import SwiftUI

struct AddTravelFormView: View {
    @Environment(\.managedObjectContext) private var viewContext
    
    @State private var name = ""
    @State private var details = " "
    @State private var price = 0.0
    @State private var startDate = Date.now
    @State private var endDate = Date.now.addingTimeInterval(86420)
    @State private var travelPoints: [TravelPoint] = []
//    @State private var newTravelPoint: TravelPoint
    
    @Binding var isVisible: Bool
    
    
    let dateRange: ClosedRange<Date> = {
        let calendar = Calendar.current
        
        let today = Date()
        let startComponents = calendar.dateComponents([.year, .month, .day], from: today)
        let endComponents = DateComponents(year: 2022, month: 12, day: 31, hour: 23, minute: 59, second: 59)
        
        return calendar.date(from:startComponents)!
            ...
            calendar.date(from:endComponents)!
    }()

    private func addItem() {
            let newItem = Travel(context: viewContext)
            newItem.id = UUID()
            newItem.name = self.name
        newItem.details = self.details
        newItem.price = Double(self.price)
        newItem.startDate = self.startDate
        newItem.endDate = self.endDate
        newItem.points = []
        
            do {
                try viewContext.save()
            } catch {
                // Replace this implementation with code to handle the error appropriately.
                // fatalError() causes the application to generate a crash log and terminate. You should not use this function in a shipping application, although it may be useful during development.
                let nsError = error as NSError
                fatalError("Unresolved error \(nsError), \(nsError.userInfo)")
            }
    }
    
    var body: some View {
        NavigationView {
            Form {
                Section(header: Text("Meeting Info")) {
                    HStack {
                        Text("Title:")
                        TextField("", text: $name)
                    }
                    HStack {
                        Text("Number: ")
                        TextField("Number", text: Binding(
                            get: { String(price) },
                            set: { price = Double($0) ?? 0.00 }
                        )).keyboardType(.numberPad)
                    }
                    HStack {
                        Text("Desciption: ")
                        TextField("", text: $details)
                    }
                
                }
                Section(header: Text("Time")) {
                    DatePicker(
                            "Start Date",
                             selection: $startDate,
                             in: dateRange,
                             displayedComponents: [.hourAndMinute, .date]
                        )
                    DatePicker(
                            "End Date",
                             selection: $endDate,
                             in: dateRange,
                             displayedComponents: [.hourAndMinute, .date]
                        )
                }
            }
            .navigationTitle("New Travel")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button {
                        isVisible = false
                    } label: {
                        Text("Cancel").foregroundColor(.red)
                    }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button {
                        isVisible = false
                        addItem()
                    } label: {
                        Text("Add")
                    }
                }
            }
        }
    }
    
  
}

struct AddTravelFormView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView{
            AddTravelFormView(isVisible: .constant(true))
        }
    }
}
