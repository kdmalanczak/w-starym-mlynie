//
//  Travel+CoreDataProperties.swift
//  travel
//
//  Created by Emil Małańczak on 06/11/2022.
//
//

import Foundation
import CoreData


extension Travel {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Travel> {
        return NSFetchRequest<Travel>(entityName: "Travel")
    }

    @NSManaged public var id: UUID?
    @NSManaged public var name: String?
    @NSManaged public var details: String?
    @NSManaged public var price: Double
    @NSManaged public var startDate: Date?
    @NSManaged public var endDate: Date?
    @NSManaged public var points: NSSet?

    public var wrappedName: String {
        name ?? "Unknown name"
    }
    
    public var wrappedStartDate: Date {
        startDate ?? Date()
    }
    
    public var pointsArray: [TravelPoint] {
            let set = points as? Set<TravelPoint> ?? []
        
        return set.sorted {
            $0.wrappedName > $1.wrappedName
        }
    }
}

// MARK: Generated accessors for points
extension Travel {

    @objc(addPointsObject:)
    @NSManaged public func addToPoints(_ value: TravelPoint)

    @objc(removePointsObject:)
    @NSManaged public func removeFromPoints(_ value: TravelPoint)

    @objc(addPoints:)
    @NSManaged public func addToPoints(_ values: NSSet)

    @objc(removePoints:)
    @NSManaged public func removeFromPoints(_ values: NSSet)

}

extension Travel : Identifiable {

}
