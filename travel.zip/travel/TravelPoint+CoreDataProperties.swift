//
//  TravelPoint+CoreDataProperties.swift
//  travel
//
//  Created by Emil Małańczak on 06/11/2022.
//
//

import Foundation
import CoreData


extension TravelPoint {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<TravelPoint> {
        return NSFetchRequest<TravelPoint>(entityName: "TravelPoint")
    }

    @NSManaged public var id: UUID?
    @NSManaged public var name: String?
    @NSManaged public var long: NSDecimalNumber?
    @NSManaged public var lang: NSDecimalNumber?
    @NSManaged public var origin: Travel?
    
    public var wrappedName: String {
        name ?? "Unknown name"
    } 

}

extension TravelPoint : Identifiable {

}
