export const DEFAULT_PLAYER = {
  //   TODO: find avatar placeholder img
  avatar: 'https://eu.cdn.beatsaver.com/eed7fc6935a86b9ad1248107ae6b2f65d9da7a1f.jpg',
  //   TODO: find country flags package
  country: 'https://eu.cdn.beatsaver.com/eed7fc6935a86b9ad1248107ae6b2f65d9da7a1f.jpg',
  countryRanking: 'NaN',
  worldRanking: 'NaN',
  performancePoint: 'NaN'
}
export const DEFAULT_SONG = {
  photo: 'https://eu.cdn.beatsaver.com/eed7fc6935a86b9ad1248107ae6b2f65d9da7a1f.jpg',
  title: '[BLEED BLOOD]',
  mapper: 'Camellia [jabob]',
  difficulty: 'Expert+',
  songKey: '10217',
  songElapsed: '23%',
  songPercentage: '97.26'
}
