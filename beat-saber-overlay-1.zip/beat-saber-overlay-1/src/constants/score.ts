export const HP_COSTS = {
  correctCut: 1,
  wrongCut: 10,
  miss: 15,
  obstacle: 0.13, // per msec
  battery: 25
}
