export const CANVAS_ID = 'configurator-canvas'

export const CANVAS_PADDING = 20
export const DRAWER_WIDTH = 500
