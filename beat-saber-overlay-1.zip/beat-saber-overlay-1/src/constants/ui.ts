export const NUMBER_FONT_FAMILIES = ['Teko', 'Oswald', 'Montserrat', 'Montserrat Alternates']

export const TEXT_FONT_FAMILIES = [
  'Teko',
  'Oswald',
  'Neon Tubes',
  'Montserrat',
  'Montserrat Alternates'
]
