export enum Saber {
  A = 'SaberA',
  B = 'SaberB'
}
