export const transformCoordinatesToRadians = (x: number, y: number): number => Math.atan2(y, x)
