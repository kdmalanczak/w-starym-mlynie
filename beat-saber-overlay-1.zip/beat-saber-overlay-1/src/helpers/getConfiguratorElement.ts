import { CANVAS_ID } from 'constants/dom'

export const getConfiguratorElement = () => document.getElementById(CANVAS_ID)
