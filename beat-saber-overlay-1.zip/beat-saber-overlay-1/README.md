# Beat saber overlay

A web overlay for Beat Saber streamers based on HTTPStatus connection

## Docs

Currently WIP, I'll try to update READ.me in sync with code development. Feel free to ask for anything

## OBS source

```
https://morgolf.github.io/beat-saber-overlay-1/
```

### Credits

Thanks to [HyldraZolxy](https://github.com/HyldraZolxy) for helping figuring me out few things
