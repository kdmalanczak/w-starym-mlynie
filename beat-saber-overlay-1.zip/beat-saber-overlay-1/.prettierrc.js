module.exports = {
  arrowParens: 'always',
  printWidth: 100,
  semi: false,
  singleQuote: true,
  quoteProps: 'as-needed',
  tabWidth: 2,
  trailingComma: 'none',
  endOfLine: 'auto'
}
