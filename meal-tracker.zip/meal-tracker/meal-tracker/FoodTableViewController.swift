//
//  FoodTableViewController.swift
//  meal-tracker
//
//  Created by Emil Małańczak on 12/06/2022.
//

import UIKit

class FoodTableViewController: UITableViewController {
    
    var meals: [Meal] = [
        Meal(name: "breakfast", food: [
            Food(name: "yoghurt", desciption: "fruits and oats"),
            Food(name: "eggs", desciption: "scrambled eggs"),
            Food(name: "cornflakes", desciption: "cini minis!"),
        ]),
        Meal(name: "lunch", food: [
            Food(name: "tortilla", desciption: "vege with tofu and hummus"),
            Food(name: "coffee", desciption: "big soy latte"),
            Food(name: "cake", desciption: "with ice cream"),
        ]),
        Meal(name: "dinner", food: [
            Food(name: "shrimps", desciption: "in wine sauce"),
            Food(name: "white wine", desciption: "portugal dry"),
            Food(name: "salad", desciption: "salad, cheese, olive oil, tomato, olives"),
        ])
    ]
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }


    override func numberOfSections(in tableView: UITableView) -> Int {
        return meals.count
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return meals[section].food.count
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Food", for: indexPath)


        let meal = meals[indexPath.section]
        let food = meal.food[indexPath.row]
        
        var config = cell.defaultContentConfiguration()
        config.text = "\(food.name)"
        config.secondaryText = "\(food.desciption)"
        
        cell.contentConfiguration = config
        return cell
    }
    

    override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return meals[section].name
    }

}
