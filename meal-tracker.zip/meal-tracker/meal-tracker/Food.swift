//
//  Food.swift
//  meal-tracker
//
//  Created by Emil Małańczak on 12/06/2022.
//

import Foundation

struct Food {
    var name: String;
    var desciption: String
}
 
