//
//  Meal.swift
//  meal-tracker
//
//  Created by Emil Małańczak on 12/06/2022.
//

import Foundation

struct Meal {
    var name: String;
    var food: [Food]
}
 
 
