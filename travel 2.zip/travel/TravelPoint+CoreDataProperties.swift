//
//  TravelPoint+CoreDataProperties.swift
//  travel
//
//  Created by Emil Małańczak on 12/11/2022.
//
//

import Foundation
import CoreData


extension TravelPoint {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<TravelPoint> {
        return NSFetchRequest<TravelPoint>(entityName: "TravelPoint")
    }

    @NSManaged public var id: UUID?
    @NSManaged public var long: Double
    @NSManaged public var lat: Double
    @NSManaged public var name: String?
    @NSManaged public var origin: Travel?

    public var wrappedName: String {
        self.name ?? "Unknown name"
    }
}

extension TravelPoint : Identifiable {

}
