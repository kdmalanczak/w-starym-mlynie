//
//  Travel+CoreDataClass.swift
//  travel
//
//  Created by Emil Małańczak on 12/11/2022.
//
//

import Foundation
import CoreData

@objc(Travel)
public class Travel: NSManagedObject {

}
