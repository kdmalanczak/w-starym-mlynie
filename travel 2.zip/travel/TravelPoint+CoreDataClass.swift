//
//  TravelPoint+CoreDataClass.swift
//  travel
//
//  Created by Emil Małańczak on 12/11/2022.
//
//

import Foundation
import CoreData

@objc(TravelPoint)
public class TravelPoint: NSManagedObject {

}
