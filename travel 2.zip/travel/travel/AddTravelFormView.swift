//
//  AddTravelFormView.swift
//  travel
//
//  Created by Emil Małańczak on 09/11/2022.
//

import SwiftUI

struct AddOrEditTravelFormView: View {
    @Environment(\.managedObjectContext) private var viewContext
    
   
    
    private var travel: Travel?
    @State private var name = ""
    @State private var details = " "
    @State private var price = 0.0
    @State private var startDate = Date.now
    @State private var endDate = Date.now.addingTimeInterval(86420)
    @State private var travelPoints: [TravelPoint] = []
     
    @Binding var isVisible: Bool
    @State var isTravelListVisible: Bool
    
    init(travel: Travel? = nil, name: String = "", details: String = " ", price: Double = 0.0, startDate: Foundation.Date = Date.now, endDate: Foundation.Date = Date.now.addingTimeInterval(86420), travelPoints: [TravelPoint] = [], visible: Binding<Bool>) {
        self._isVisible = visible
        self.travel = travel
        self._name = State(initialValue: self.travel?.name ?? name)
        self._details = State(initialValue: self.travel?.details ?? details)
        self._price = State(initialValue: self.travel?.price ?? price)
        self._startDate = State(initialValue: self.travel?.startDate ?? startDate)
        self._endDate = State(initialValue: self.travel?.endDate ?? endDate)
        self._travelPoints = State(initialValue: travel?.pointsArray ?? travelPoints)
        self._isTravelListVisible = State(initialValue: false)
    }
    
    let dateRange: ClosedRange<Date> = {
        let calendar = Calendar.current
        
        let today = Date()
        let startComponents = calendar.dateComponents([.year, .month, .day], from: today)
        let endComponents = DateComponents(year: 2022, month: 12, day: 31, hour: 23, minute: 59, second: 59)
        
        return calendar.date(from:startComponents)!
        ...
        calendar.date(from:endComponents)!
    }()
    
    private func editItem() {
        travel!.name = self.name
        travel!.details = self.details
        travel!.price = self.price
        travel!.startDate = self.startDate
        travel!.endDate = self.endDate
        travel!.points = []
        
        self.travelPoints.forEach { point in
            point.origin = travel
        }
        
        do {
            try viewContext.save()
        } catch {
            // Replace this implementation with code to handle the error appropriately.
            // fatalError() causes the application to generate a crash log and terminate. You should not use this function in a shipping application, although it may be useful during development.
            let nsError = error as NSError
            fatalError("Unresolved error \(nsError), \(nsError.userInfo)")
        }
    }
    
    private func addItem() {
        let newItem = Travel(context: viewContext)
        newItem.id = UUID()
        newItem.name = self.name
        newItem.details = self.details
        newItem.price = self.price
        newItem.startDate = self.startDate
        newItem.endDate = self.endDate
        newItem.points = []
        
        do {
            try viewContext.save()
        } catch {
            // Replace this implementation with code to handle the error appropriately.
            // fatalError() causes the application to generate a crash log and terminate. You should not use this function in a shipping application, although it may be useful during development.
            let nsError = error as NSError
            fatalError("Unresolved error \(nsError), \(nsError.userInfo)")
        }
    }
    
    var body: some View {
        NavigationView {
            Form {
                Section(header: Text("Meeting Info")) {
                    HStack {
                        Text("Title:")
                        TextField("", text: $name)
                    }
                    HStack {
                        Text("Number: ")
                        TextField("Number", text: Binding(
                            get: { String(price) },
                            set: { price = Double($0) ?? 0.00 }
                        )).keyboardType(.numberPad)
                    }
                    HStack {
                        Text("Desciption: ")
                        TextField("", text: $details)
                    }
                    
                }
                Section(header: Text("Time")) {
                    DatePicker(
                        "Start Date",
                        selection: $startDate,
                        in: dateRange,
                        displayedComponents: [.hourAndMinute, .date]
                    )
                    DatePicker(
                        "End Date",
                        selection: $endDate,  
                        in: dateRange,
                        displayedComponents: [.hourAndMinute, .date]
                    )
                }
                Section(header: Text("Travel Points")) {
                    List {
                        if (travelPoints.count > 1) {
                                EditButton()
                        }
                        ForEach(travelPoints, id: \.self) { point in
                            Text(point.wrappedName)
                        }
                        .onMove(perform: move)
                        .onDelete(perform: removePoint)
                        Button {
                            isTravelListVisible = true
                        } label: {
                            Text("Open points list")
                        }
                    }
                    
                }
                
            }
            .navigationTitle(travel != nil ? "Edit Travel" : "New Travel")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button {
                        isVisible = false
                    } label: {
                        Text("Cancel").foregroundColor(.red)
                    }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button {
                        isVisible = false
                        travel != nil ? editItem() : addItem()
                    } label: {
                        Text(travel != nil ? "Confirm" : "Add")
                    }
                }
            }
            .sheet(isPresented: $isTravelListVisible) {
                TravelPointsList(excludedPoints: $travelPoints, onPointClick: selectPoint, visible: $isTravelListVisible)
            }
        }
    }
    
    private func selectPoint(travelPoint: TravelPoint) {
        travelPoints.append(travelPoint)
    }
    
    private func removePoint(at offsets: IndexSet) {
        travelPoints.remove(atOffsets: offsets)
        }
    
    private func move(from source: IndexSet, to destination: Int) {
        withAnimation {
            travelPoints.move(fromOffsets: source, toOffset: destination)
        }
    }
    
}

struct AddTravelFormView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView{
            AddOrEditTravelFormView(visible: .constant(true))
        }.environment(\.managedObjectContext, PersistenceController.preview.container.viewContext)
    }
}
