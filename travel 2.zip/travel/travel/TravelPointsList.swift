//
//  TravelPointsList.swift
//  travel
//
//  Created by Emil Małańczak on 12/11/2022.
//

import SwiftUI

struct TravelPointsList: View {
    @Environment(\.managedObjectContext) private var viewContext
    @Binding var excludedPoints: [TravelPoint]
    
//    @FetchRequest(
//        sortDescriptors: [NSSortDescriptor(key: #keyPath(TravelPoint.name), ascending: true)],
//        predicate: NSPredicate(format: "NOT (item_id IN %@)", excludedPoints), animation: .default)
    @FetchRequest(
        sortDescriptors: [NSSortDescriptor(key: #keyPath(TravelPoint.name), ascending: true)], animation: .default)
    private var existingPoints: FetchedResults<TravelPoint>
    
    var onPointClick: (TravelPoint) -> Void
    
    @Binding var visible: Bool
    @State var isAddModeOn = false
    
    var body: some View {
        NavigationView {
            VStack {
                List {
                    ForEach(existingPoints.indices, id: \.self)  { index in
                        Button {
                            onPointClick(existingPoints[index])
                            visible = false
                        } label: {
                            VStack(alignment: .leading) {
                                Text(existingPoints[index].wrappedName)
                                HStack {
                                    Text("Long: \(existingPoints[index].long)")
                                    Text("Lat: \(existingPoints[index].lat)")
                                }.font(.footnote).foregroundColor(.gray)
                            }.padding(.vertical, 2)
                        }
                    }
                    .onDelete(perform: deleteItems)
                }
            }
            .sheet(isPresented: $isAddModeOn) {
                AddOrEditTravelPoint(visible: $isAddModeOn)
            }
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button {
                        visible = false
                    } label: {
                        Text("Cancel").foregroundColor(.red)
                    }
                }
                ToolbarItem(placement: .navigationBarTrailing) {
                    EditButton()
                }
                ToolbarItem {
                    Button(action: {
                        isAddModeOn = true
                    }) {
                        Label("Add Item", systemImage: "plus")
                    }
                }
            }
        }
        
    }
    
    private func deleteItems(offsets: IndexSet) {
        withAnimation {
            offsets.map { existingPoints[$0] }.forEach { point in
                point.origin = nil
                viewContext.delete(point)
            }
            
            do {
                try viewContext.save()
            } catch {
                // Replace this implementation with code to handle the error appropriately.
                // fatalError() causes the application to generate a crash log and terminate. You should not use this function in a shipping application, although it may be useful during development.
                let nsError = error as NSError
                fatalError("Unresolved error \(nsError), \(nsError.userInfo)")
            }
        }
    }
}

struct TravelPointsList_Previews: PreviewProvider {
    static var previews: some View {
        TravelPointsList(excludedPoints: .constant([]), onPointClick: {travel in}, visible: .constant(true)).environment(\.managedObjectContext, PersistenceController.preview.container.viewContext)
    }
}
