//
//  AddOrEditTravelPoint.swift
//  travel
//
//  Created by Emil Małańczak on 12/11/2022.
//

import SwiftUI

struct AddOrEditTravelPoint: View {
    @Environment(\.managedObjectContext) private var viewContext
    
    @Binding var isVisible: Bool
    
    private var travelPoint: TravelPoint?
    private var onAddTravelPoint: ((TravelPoint) -> Void)?
    @State private var name = ""
    @State private var long = 0.0
    @State private var lat = 0.0
    
    init(travelPoint: TravelPoint? = nil, name: String = "", long: Double = 0.0, lat: Double = 0.0, visible: Binding<Bool>, onAddTravelPoint: ((TravelPoint) -> Void)? = nil) {
        self._isVisible = visible
        self.travelPoint = travelPoint
        self.onAddTravelPoint = onAddTravelPoint
        self._name = State(initialValue: self.travelPoint?.name ?? name)
        self._long = State(initialValue: self.travelPoint?.long ?? long)
        self._lat = State(initialValue: self.travelPoint?.lat ?? lat)
        
      
    }
    
    var body: some View {
        NavigationView {
            Form {
                Section("Information") {
                    HStack {
                        Text("Title:")
                        TextField("", text: $name)
                    }
                }
                Section("Place coordinates") {
                    HStack {
                        Text("Longitude: ")
                        TextField("Number", text: Binding(
                            get: { String(long) },
                            set: { long = Double($0) ?? 0.00 }
                        )).keyboardType(.numberPad)
                    }
                    HStack {
                        Text("Latitude: ")
                        TextField("Number", text: Binding(
                            get: { String(lat) },
                            set: { lat = Double($0) ?? 0.00 }
                        )).keyboardType(.numberPad)
                    }
                }
                Button {
                    randomValues()
                } label: {
                    Text("Random values")
                }
            }
            .navigationTitle(travelPoint != nil ? "Edit Travel Point" : "New Travel Point")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button {
                        isVisible = false
                    } label: {
                        Text("Cancel").foregroundColor(.red)
                    }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button {
                        isVisible = false
                        travelPoint != nil ? editItem() : addItem()
                    } label: {
                        Text(travelPoint != nil ? "Edit" : "Add")
                    }
                }
            }
        }
    }
    
    private func editItem() {
        travelPoint!.name = self.name
        travelPoint!.long = self.long
        travelPoint!.lat = self.lat
//        travel!.points = self.travelPoints
        
        do {
            try viewContext.save()
        } catch {
            // Replace this implementation with code to handle the error appropriately.
            // fatalError() causes the application to generate a crash log and terminate. You should not use this function in a shipping application, although it may be useful during development.
            let nsError = error as NSError
            fatalError("Unresolved error \(nsError), \(nsError.userInfo)")
        }
    }
    
    private func addItem() {
        let newItem = TravelPoint(context: viewContext)
        newItem.id = UUID()
        newItem.name = self.name
        newItem.long = self.long
        newItem.lat = self.lat
        
        do {
            try viewContext.save()
        } catch {
            // Replace this implementation with code to handle the error appropriately.
            // fatalError() causes the application to generate a crash log and terminate. You should not use this function in a shipping application, although it may be useful during development.
            let nsError = error as NSError
            fatalError("Unresolved error \(nsError), \(nsError.userInfo)")
        }
    }
    
    private func randomValues() {
        name = "Wrocław \(Int.random(in: 1..<400))"
        long = Double.random(in: 17.038..<17.39)
        lat = Double.random(in: 51.1065..<51.1085)
    }
}

struct AddOrEditTravelPoint_Previews: PreviewProvider {
    static var previews: some View {
        AddOrEditTravelPoint(visible: .constant(true))
    }
}
