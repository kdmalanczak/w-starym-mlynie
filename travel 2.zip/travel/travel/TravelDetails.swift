//
//  TravelDetails.swift
//  travel
//
//  Created by Emil Małańczak on 12/11/2022.
//

import SwiftUI
import MapKit

struct TravelDetails: View {
    @ObservedObject var travel: Travel
    @State var isEditing = false
    @State private var region: MKCoordinateRegion
    
    init(travel: ObservedObject<Travel>) {
        self._travel = travel
        self._isEditing = State(initialValue: false)
        let firstPoint = travel.wrappedValue.pointsArray.count > 0 ? travel.wrappedValue.pointsArray[0] : nil
        self._region = State(initialValue: MKCoordinateRegion(center: CLLocationCoordinate2D(latitude: firstPoint?.lat ?? 0.0, longitude: firstPoint?.long ?? 0.0),
                                                    span: MKCoordinateSpan(latitudeDelta: 0.2, longitudeDelta: 0.2)))
    }
    
    var body: some View {
        List {
            Section("Info") {
                HStack {
                    Text("Title")
                    Spacer()
                    Text(travel.wrappedName).foregroundColor(.gray)
                }
                HStack {
                    Text("Price")
                    Spacer()
                    Text(String(format: "%.2f", travel.price)).foregroundColor(.gray)
                }
                
            }
            Section("Travel points") {
                ForEach(travel.pointsArray) { point in
                    VStack(alignment: .leading, spacing: 2) {
                        HStack {
                            Text(point.wrappedName)
                            Spacer()
                        }
                        HStack(spacing: 4) {
                            Text("Long: \(String(format: "%.3f", point.long))")
                            Text("Lat: \(String(format: "%.3f", point.lat))")
                        }.foregroundColor(.gray).font(.footnote)
                    }
                }
            }
            Section("Map") {
                Map(coordinateRegion: $region, annotationItems: travel.pointsArray) { place in
                    MapMarker(coordinate: CLLocationCoordinate2D(latitude: place.lat, longitude: place.long), tint: Color.accentColor)
                }
                .ignoresSafeArea(edges: .top)
                .frame(height: 300).cornerRadius(8)
            }
        }
        .navigationTitle(travel.wrappedName)
        .toolbar {
            ToolbarItem(placement: .navigationBarTrailing) {
                Button {
                    isEditing = true
                } label: {
                    HStack {
                        Label("Edit", systemImage: "pencil")
                        Text("Edit")
                    }
                }
            }
            
        }
        .sheet(isPresented: $isEditing) {
            AddOrEditTravelFormView(travel: travel, visible: $isEditing)
        }
    }
}
