//
//  AddCityUiController.swift
//  zadanie2
//
//  Created by Emil Małańczak on 12/06/2022.
//

import UIKit

class AddCityUiController: UIViewController {
    @IBOutlet weak var cityField: UITextField!
    var cityName: String!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let newCity = cityField.text {
            cityName = newCity
        }
    }
   
}
