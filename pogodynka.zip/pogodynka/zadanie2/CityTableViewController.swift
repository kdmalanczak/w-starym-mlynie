//
//  CityTableViewController.swift
//  zadanie2
//
//  Created by Emil Małańczak on 12/06/2022.
//

import UIKit

class CityTableViewController: UITableViewController {
    var cities: [City] = [
        City(name: "Wrocław"),
        City(name: "Warszawa"),
        City(name: "Kraków"),
        City(name: "Łódź")
    ]
    
    var selectedCity = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
      
    }

    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return cities.count
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "City", for: indexPath)


        let city = cities[indexPath.row]
        
        var config = cell.defaultContentConfiguration()
        config.text = "\(city.name)"
        
        cell.contentConfiguration = config
        return cell
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        selectedCity = cities[indexPath.row].name
        
        performSegue(withIdentifier: "cityIdentifier", sender: nil)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "cityIdentifier" {
            if let viewController  = segue.destination as? ViewController {
                viewController.loadViewIfNeeded()
                viewController.cityName.text = selectedCity
            }
        }
        
        if segue.identifier == "addCity" {
            if let viewController  = segue.destination as? ViewController {
                viewController.loadViewIfNeeded()
                viewController.cityName.text = selectedCity
            }
        }
    }
   
    @IBAction func unwindToTableView(segue: UIStoryboardSegue) {
        if segue.source is AddCityUiController {
            
            if let controller = segue.source as? AddCityUiController {
                let newCity = controller.cityName ?? "null"

                cities.append(City(name: newCity))
                tableView.reloadData()
            }
            
        }
    }
}
 
