//
//  ViewController.swift
//  zadanie2
//
//  Created by Emil Małańczak on 08/05/2022.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var cityName: UILabel!
    @IBOutlet weak var stack: UIStackView!
    @IBOutlet weak var blurredView: UIVisualEffectView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        blurredView.layer.cornerRadius = 10
        blurredView.clipsToBounds = true
    }
    
    
}

