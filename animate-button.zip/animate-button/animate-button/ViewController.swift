//
//  ViewController.swift
//  animate-button
//
//  Created by Emil Małańczak on 12/06/2022.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var button: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    @IBAction func buttonClick(_ sender: Any) {

        UIView.animate(withDuration: 0.3,
            animations: { [self] in
                self.button.transform = CGAffineTransform(scaleX: 1.2, y: 1.2)
            },
            completion: { _ in
                UIView.animate(withDuration: 0.6) {
                    self.button.transform = CGAffineTransform.identity
                }
            }
        )
        
    }
   
}
    
 

